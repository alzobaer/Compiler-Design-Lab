#include<bits/stdc++.h>
using namespace std;
int main(){
	char str[10];
	string c, s, e;
	freopen("input.txt", "r", stdin);
	gets(str);
	int i = 0;


}
